export interface ImageState {
  file: File | null;
  previewUrl: string | null;
  base64: string | null;
  mimeType: string | null;
}

export interface GenerationState {
  isLoading: boolean;
  resultUrl: string | null;
  error: string | null;
}

export enum AppMode {
  UPLOAD = 'UPLOAD',
  EDIT = 'EDIT',
  RESULT = 'RESULT'
}