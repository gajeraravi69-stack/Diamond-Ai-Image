
import { GoogleGenAI } from "@google/genai";

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Enhanced generation with "Quota Hopping".
 * Automatically fails over between models to find one with available quota.
 */
export const generateJewelryImage = async (
  base64Data: string,
  mimeType: string,
  prompt: string,
  preferredModel: 'gemini-pro' | 'gemini-flash' = 'gemini-pro'
): Promise<{ imageUrl: string; modelUsed: string }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Define the fallback chain based on preference
  // If user prefers Pro: Pro -> Flash -> Exp
  // If user prefers Flash: Flash -> Pro -> Exp
  const modelChain = preferredModel === 'gemini-pro' 
    ? ['gemini-3-pro-image-preview', 'gemini-2.5-flash-image']
    : ['gemini-2.5-flash-image', 'gemini-3-pro-image-preview'];

  let lastError: any = null;

  for (const modelName of modelChain) {
    try {
      console.log(`Attempting generation with: ${modelName}`);
      
      const config: any = {};
      
      // Add specific configs per model type
      if (modelName === 'gemini-3-pro-image-preview') {
         config.imageConfig = { imageSize: '2K', aspectRatio: '1:1' };
      } else {
         // Flash/Exp models don't support imageSize, so we leave it undefined
      }

      // Create a new instance for each attempt to ensure clean state
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: modelName,
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            {
              text: `${prompt}
              
              CRITICAL REQUIREMENTS:
              - STRICTLY PRESERVE the exact shape, geometry, and design of the reference jewelry.
              - Do NOT modify the jewelry structure or gemstones.
              - The goal is to place the *exact same* item into a new context.
              - Photorealistic jewelry photography.
              - High detail on metal and gems.
              - Professional lighting.
              `
            },
          ],
        },
        config
      });

      const candidate = response.candidates?.[0];
      if (candidate) {
        for (const part of candidate.content.parts) {
          if (part.inlineData && part.inlineData.data) {
            return {
              imageUrl: `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`,
              modelUsed: modelName
            };
          }
        }
      }
      
      // If we got a response but no image, it's a soft failure, try next model
      console.warn(`Model ${modelName} returned no image.`);

    } catch (error: any) {
      console.warn(`Failed with ${modelName}:`, error.message);
      lastError = error;
      
      // If it's a Rate Limit (429) or Quota (403/ResourceExhausted), we continue to next model loop immediately.
      // If it's a 404 (Model not found), we also continue.
      // We also continue on PERMISSION_DENIED (403) to fallback from paid models to free ones.
      const isRecoverable = 
        error.message?.includes('429') || 
        error.message?.includes('404') || 
        error.message?.includes('quota') ||
        error.message?.includes('RESOURCE_EXHAUSTED') ||
        error.message?.includes('PERMISSION_DENIED') ||
        error.message?.includes('403') ||
        error.status === 429 ||
        error.status === 503 ||
        error.status === 403;

      if (!isRecoverable) {
         // If it's a critical error (like auth), break and throw
         throw error;
      }
      
      // Short pause before hopping to next model to prevent spamming
      await wait(500);
    }
  }

  // If we exhausted all models
  if (lastError) {
    throw new Error("Daily quota exhausted on ALL models. Please try again tomorrow or use a different API key.");
  }
  
  throw new Error("Failed to generate image.");
};
