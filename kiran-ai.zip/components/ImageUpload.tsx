
import React, { useCallback, useRef, useState } from 'react';
import { fileToBase64, getMimeType } from '../utils/fileHelpers';
import { ImageState } from '../types';

interface ImageUploadProps {
  onImageSelect: (state: ImageState) => void;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({ onImageSelect }) => {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    if (!file.type.startsWith('image/')) return;

    try {
      const base64 = await fileToBase64(file);
      const previewUrl = URL.createObjectURL(file);
      
      onImageSelect({
        file,
        previewUrl,
        base64,
        mimeType: getMimeType(file)
      });
    } catch (err) {
      console.error("Error processing file", err);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.[0]) processFile(e.dataTransfer.files[0]);
  }, []);

  return (
    <div 
      className={`w-full aspect-video border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer
        ${isDragging ? 'border-yellow-500 bg-yellow-500/5' : 'border-zinc-800 bg-black/20 hover:border-zinc-700'}
      `}
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input type="file" ref={inputRef} className="hidden" accept="image/*" onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])} />
      <div className="bg-zinc-800 p-4 rounded-full mb-3 text-zinc-500 group-hover:text-zinc-300 transition-colors">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
        </svg>
      </div>
      <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Upload Asset</span>
    </div>
  );
};
