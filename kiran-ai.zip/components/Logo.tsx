import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "" }) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* The Visor Shape Container */}
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Visor Background Shape using SVG Mask/ClipPath for precision */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid meet">
          <defs>
            <clipPath id="visorClip">
              <path d="M50,50 C50,22.38 72.38,0 100,0 H700 C727.62,0 750,22.38 750,50 V300 C750,327.62 727.62,350 700,350 H500 C450,350 425,280 400,280 C375,280 350,350 300,350 H100 C72.38,350 50,327.62 50,300 Z" />
            </clipPath>
            <linearGradient id="visorBg" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1e3a5f" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
          </defs>
          
          {/* Main Background with Faceted Pattern */}
          <rect x="50" y="0" width="700" height="350" fill="url(#visorBg)" clipPath="url(#visorClip)" />
          
          {/* Faceted Pattern Overlay - More geometric and visible like the image */}
          <g clipPath="url(#visorClip)" opacity="0.2">
            <path d="M50,0 L300,100 L100,200 Z" fill="white" />
            <path d="M300,0 L500,50 L400,150 Z" fill="white" />
            <path d="M500,0 L750,100 L600,200 Z" fill="white" />
            <path d="M50,200 L250,150 L300,350 Z" fill="white" />
            <path d="M750,200 L550,150 L500,350 Z" fill="white" />
            <path d="M300,350 L400,200 L500,350 Z" fill="white" />
          </g>

          {/* Top Glow Arc */}
          <path d="M150,60 Q400,30 650,60" fill="none" stroke="white" strokeWidth="3" strokeOpacity="0.4" filter="blur(2px)" />
        </svg>

        {/* Logo Text and Icons - Positioned and scaled to fit inside the visor */}
        <div className="relative z-10 flex items-center justify-center w-full h-full px-12">
          <div className="flex items-center text-white scale-[0.85]">
            {/* Kiran */}
            <div className="flex items-end">
              <span className="text-5xl font-bold tracking-tighter">K</span>
              <div className="relative flex flex-col items-center">
                {/* Line Art Diamond Icon */}
                <svg className="absolute -top-8 w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 4L2 10L12 22L22 10L18 4H6Z" />
                  <path d="M2 10H22" />
                  <path d="M12 22L7 10" />
                  <path d="M12 22L17 10" />
                </svg>
                <span className="text-5xl font-bold tracking-tighter">i</span>
              </div>
              <span className="text-5xl font-bold tracking-tighter">ran</span>
            </div>

            {/* Sparkle Star */}
            <div className="mx-3 relative">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <defs>
                  <linearGradient id="starGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#c084fc" />
                    <stop offset="100%" stopColor="#60a5fa" />
                  </linearGradient>
                </defs>
                <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" fill="url(#starGrad)" />
              </svg>
              {/* Smaller secondary star */}
              <svg className="absolute -top-3 -right-1 w-3 h-3" viewBox="0 0 24 24" fill="#c084fc">
                <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
              </svg>
            </div>

            {/* ai */}
            <div className="flex items-end">
              <span className="text-5xl font-bold tracking-tighter">a</span>
              <div className="relative flex flex-col items-center">
                {/* Line Art Diamond Icon */}
                <svg className="absolute -top-8 w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 4L2 10L12 22L22 10L18 4H6Z" />
                  <path d="M2 10H22" />
                  <path d="M12 22L7 10" />
                  <path d="M12 22L17 10" />
                </svg>
                <span className="text-5xl font-bold tracking-tighter">i</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
