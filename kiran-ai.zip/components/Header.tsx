
import React from 'react';
import { Logo } from './Logo';

export const Header: React.FC = () => {
  return (
    <header className="w-full pt-8 pb-4 px-6">
      <div className="max-w-5xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Logo className="w-64 h-24 sm:w-80 sm:h-32" />
          <div className="hidden md:block border-l border-white/10 pl-6">
            <p className="text-[11px] text-zinc-400 uppercase tracking-[0.3em] font-semibold">Next-Gen Jewelry AI</p>
            <p className="text-[9px] text-zinc-500 uppercase tracking-[0.2em] font-bold mt-1">Powered by Gemini 3.1</p>
          </div>
        </div>
      </div>
    </header>
  );
};