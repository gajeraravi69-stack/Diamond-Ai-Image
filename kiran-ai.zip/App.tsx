
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ImageUpload } from './components/ImageUpload';
import { ImageState, GenerationState } from './types';
import { generateJewelryImage } from './services/geminiService';

const DAILY_LIMIT = 50; // Estimated daily limit for free tier

const PRESETS = [
  { 
    label: 'UGC Handheld', 
    icon: '✋', 
    prompt: 'Create a realistic UGC style photo of this EXACT jewelry being worn on a hand. Do not change the jewelry design. Close-up, first-person POV, natural skin texture, soft daylight, blurred lifestyle background.' 
  },
  { 
    label: 'Velvet Display', 
    icon: '🖤', 
    prompt: 'Place this EXACT jewelry on a luxurious black velvet display stand. Do not alter the item. High-contrast studio lighting, sparkling diamonds, sharp macro details, commercial product photography.' 
  },
  { 
    label: 'Max Brilliance', 
    icon: '💎', 
    prompt: 'Enhance the jewelry image while strictly preserving the original shape and geometry. Maximize the fire, scintillation, and brilliance of the stones. Make it look like a high-end catalogue shot.' 
  },
  { 
    label: 'Editorial Model', 
    icon: '💃', 
    prompt: 'A fashion editorial shot of a model wearing this EXACT jewelry. Do not modify the jewelry. Soft focus background, elegant pose, skin retouching, cinematic lighting.' 
  }
];

const App: React.FC = () => {
  const [imageState, setImageState] = useState<ImageState>({
    file: null,
    previewUrl: null,
    base64: null,
    mimeType: null
  });

  const [prompt, setPrompt] = useState(PRESETS[0].prompt);
  const [activePreset, setActivePreset] = useState<string | null>(PRESETS[0].label);
  const [preference, setPreference] = useState<'gemini-pro' | 'gemini-flash'>('gemini-pro');
  
  // Track which model actually did the work
  const [usedModel, setUsedModel] = useState<string | null>(null);

  const [generationState, setGenerationState] = useState<GenerationState>({
    isLoading: false,
    resultUrl: null,
    error: null
  });

  const [usageCount, setUsageCount] = useState(0);
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const todayStr = now.toDateString();
      
      // Check for automatic reset at midnight
      const storedData = localStorage.getItem('luxe_jewel_usage');
      if (storedData) {
        const { date } = JSON.parse(storedData);
        if (date !== todayStr) {
          setUsageCount(0);
          localStorage.setItem('luxe_jewel_usage', JSON.stringify({ count: 0, date: todayStr }));
        }
      }

      const tomorrow = new Date();
      tomorrow.setDate(now.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);
      
      const diff = tomorrow.getTime() - now.getTime();
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      
      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const today = new Date().toDateString();
    const storedData = localStorage.getItem('luxe_jewel_usage');
    if (storedData) {
      const { count, date } = JSON.parse(storedData);
      if (date === today) {
        setUsageCount(count);
      } else {
        localStorage.setItem('luxe_jewel_usage', JSON.stringify({ count: 0, date: today }));
      }
    } else {
      localStorage.setItem('luxe_jewel_usage', JSON.stringify({ count: 0, date: today }));
    }
  }, []);

  const incrementUsage = () => {
    const today = new Date().toDateString();
    const newCount = usageCount + 1;
    setUsageCount(newCount);
    localStorage.setItem('luxe_jewel_usage', JSON.stringify({ count: newCount, date: today }));
  };

  const setMaxUsage = () => {
    const today = new Date().toDateString();
    setUsageCount(DAILY_LIMIT);
    localStorage.setItem('luxe_jewel_usage', JSON.stringify({ count: DAILY_LIMIT, date: today }));
  };

  const handleGenerate = async () => {
    if (!imageState.base64 || !imageState.mimeType) {
      setGenerationState(prev => ({ ...prev, error: "Please upload a reference image first." }));
      return;
    }

    setGenerationState(prev => ({ ...prev, isLoading: true, error: null, resultUrl: null }));
    setUsedModel(null);

    try {
      const result = await generateJewelryImage(
        imageState.base64,
        imageState.mimeType,
        prompt,
        preference
      );
      setGenerationState(prev => ({ ...prev, isLoading: false, resultUrl: result.imageUrl }));
      setUsedModel(result.modelUsed);
      incrementUsage();
    } catch (error: any) {
      let errorMessage = error.message || "An unexpected error occurred.";
      
      if (errorMessage.includes("quota") || errorMessage.includes("exhausted")) {
        errorMessage = "⚠️ All daily quotas exhausted. Please try again tomorrow.";
        setMaxUsage();
      }

      setGenerationState(prev => ({ ...prev, isLoading: false, error: errorMessage }));
    }
  };

  const handlePresetClick = (p: typeof PRESETS[0]) => {
    setActivePreset(p.label);
    setPrompt(p.prompt);
  };

  const getModelDisplayName = (modelId: string) => {
    if (modelId.includes('pro')) return 'GEMINI PRO';
    if (modelId.includes('flash-exp')) return 'GEMINI EXPERIMENTAL';
    if (modelId.includes('flash')) return 'GEMINI FLASH';
    return 'GEMINI AI';
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#09090b] text-[#e4e4e7]">
      <Header />

      <main className="flex-1 max-w-[1440px] mx-auto w-full px-6 py-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start h-full">
          
          {/* Input Section */}
          <div className="space-y-6 bg-[#111114]/80 p-6 rounded-[2.5rem] border border-white/5 backdrop-blur-xl shadow-2xl relative overflow-hidden">
            {/* Decorative gradient glow */}
            <div className="absolute -top-20 -left-20 w-64 h-64 bg-yellow-600/10 rounded-full blur-[100px] pointer-events-none"></div>

            <div className="flex justify-between items-center px-1 relative z-10">
              <div className="flex flex-col">
                <h2 className="text-zinc-300 font-medium text-lg">Studio Controls</h2>
                <div className="flex items-center gap-4 mt-2">
                  <div className="h-2 w-32 bg-zinc-800 rounded-full overflow-hidden shadow-inner">
                    <div 
                      className={`h-full transition-all duration-500 shadow-[0_0_10px_rgba(238,176,30,0.3)] ${usageCount >= DAILY_LIMIT ? 'bg-red-500' : 'bg-[#eeb01e]'}`}
                      style={{ width: `${Math.min((usageCount / DAILY_LIMIT) * 100, 100)}%` }}
                    ></div>
                  </div>
                  <div className="flex items-center gap-4 flex-1">
                    <span className="text-[11px] font-black uppercase tracking-[0.15em] text-zinc-400">
                      Usage: <span className={usageCount >= DAILY_LIMIT ? 'text-red-500' : 'text-white'}>{usageCount}</span>/{DAILY_LIMIT}
                    </span>
                    <span className="text-[11px] font-bold text-zinc-500 ml-auto flex items-center gap-1.5 bg-black/30 px-3 py-1 rounded-full border border-white/5">
                      <svg className="w-3 h-3 text-[#eeb01e]/70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                      <span className="text-zinc-300">Reset:</span> {timeLeft}
                    </span>
                  </div>
                </div>
              </div>
              
              {/* Preference Selector */}
              <div className="flex items-center gap-2 bg-black/40 rounded-lg p-1 border border-zinc-800">
                <button
                  onClick={() => setPreference('gemini-pro')}
                  className={`px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all
                    ${preference === 'gemini-pro' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}
                  `}
                >
                  Quality First
                </button>
                <button
                  onClick={() => setPreference('gemini-flash')}
                  className={`px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all
                    ${preference === 'gemini-flash' ? 'bg-[#eeb01e]/20 text-[#eeb01e] shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}
                  `}
                >
                  Speed First
                </button>
              </div>
            </div>

            <div className="relative z-10">
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full bg-black/60 border border-zinc-800 rounded-2xl p-6 text-zinc-100 focus:ring-1 focus:ring-[#eeb01e]/50 outline-none h-32 resize-none text-base leading-relaxed shadow-inner"
                placeholder="Describe the scene..."
              />
            </div>

            <div className="flex flex-wrap gap-2 relative z-10">
              {PRESETS.map((p) => (
                <button
                  key={p.label}
                  onClick={() => handlePresetClick(p)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-[11px] font-bold uppercase tracking-wider transition-all border
                    ${activePreset === p.label 
                      ? 'bg-[#eeb01e] border-[#eeb01e] text-black shadow-lg shadow-yellow-900/20' 
                      : 'bg-[#18181b] border-zinc-800 text-zinc-500 hover:bg-zinc-800'
                    }`}
                >
                  <span>{p.icon}</span>
                  {p.label}
                </button>
              ))}
            </div>

            <div className="space-y-3 relative z-10">
               <label className="text-[10px] uppercase font-black tracking-[0.2em] text-zinc-600 block px-1 text-center">Reference Jewel</label>
               {imageState.file ? (
                  <div className="relative w-full aspect-[16/9] rounded-2xl overflow-hidden border border-zinc-800 bg-black group shadow-2xl">
                     <img src={imageState.previewUrl!} className="w-full h-full object-contain" alt="Reference" />
                     <button 
                       onClick={() => setImageState({ file: null, previewUrl: null, base64: null, mimeType: null })}
                       className="absolute top-4 right-4 bg-black/80 w-10 h-10 rounded-full text-white hover:bg-black transition-all flex items-center justify-center border border-white/10 opacity-0 group-hover:opacity-100"
                     >
                       ✕
                     </button>
                  </div>
               ) : (
                  <ImageUpload onImageSelect={setImageState} />
               )}
            </div>

            <button 
              onClick={handleGenerate}
              disabled={generationState.isLoading}
              className="w-full py-6 rounded-2xl font-black text-xl text-black shadow-[0_20px_50px_-10px_rgba(238,176,30,0.2)] transition-all active:scale-[0.98] disabled:opacity-50
              bg-gradient-to-b from-[#eeb01e] to-[#bfa05e] hover:brightness-110 tracking-[0.1em] uppercase relative z-10"
            >
              {generationState.isLoading ? 'Processing Request...' : 'Generate Image'}
            </button>

            {generationState.error && (
              <div className="bg-[#1c0d0d] border border-[#3f1616] p-5 rounded-2xl relative z-10 animate-in fade-in slide-in-from-top-2">
                <div className="flex items-start gap-3">
                  <span className="text-xl">⚠️</span>
                  <p className="text-[#ef4444] font-mono text-xs leading-relaxed pt-1">{generationState.error}</p>
                </div>
              </div>
            )}
            
            <p className="text-[10px] text-zinc-600 text-center relative z-10">
              *The system will automatically try multiple engines to find free quota.
            </p>
          </div>

          {/* Output Section */}
          <div className="lg:sticky lg:top-10 h-fit">
            <div className="bg-[#050505] border border-white/5 rounded-[3rem] p-5 min-h-[600px] flex flex-col shadow-2xl relative">
              <div className="flex-1 flex items-center justify-center relative rounded-[2.5rem] overflow-hidden bg-zinc-950/30 border border-white/5">
                
                {generationState.isLoading && (
                  <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/95 backdrop-blur-2xl transition-all">
                    <div className="relative w-28 h-28 mb-8">
                      <div className="absolute inset-0 border-[6px] border-[#eeb01e]/10 rounded-full"></div>
                      <div className="absolute inset-0 border-[6px] border-t-[#eeb01e] rounded-full animate-spin"></div>
                    </div>
                    <p className="text-[#eeb01e] font-black uppercase tracking-[0.4em] text-[10px] animate-pulse text-center px-6">
                      FINDING SERVER...<br/><span className="mt-2 block opacity-60 text-white">Checking Available Models</span>
                    </p>
                  </div>
                )}

                {generationState.resultUrl ? (
                  <div className="w-full h-full p-2 relative group">
                    <img 
                      src={generationState.resultUrl} 
                      className="w-full h-full object-contain rounded-[2rem] shadow-2xl animate-in zoom-in-95 duration-700" 
                      alt="Result" 
                    />
                    <div className="absolute top-6 left-6 flex gap-2">
                       <span className="bg-black/60 backdrop-blur px-3 py-1 rounded text-[8px] font-black border border-white/10 text-white tracking-widest uppercase">HD</span>
                       {usedModel && (
                         <span className="bg-blue-900/30 backdrop-blur px-3 py-1 rounded text-[8px] font-black border border-blue-500/40 text-blue-300 tracking-widest uppercase">
                           {getModelDisplayName(usedModel)}
                         </span>
                       )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-12 opacity-5">
                    <div className="w-48 h-48 mx-auto mb-8 border border-white/20 rounded-full flex items-center justify-center">
                       <span className="text-6xl font-serif text-white/50">AI</span>
                    </div>
                    <p className="font-serif italic text-3xl tracking-[0.2em] uppercase text-[#eeb01e]">Digital Canvas</p>
                  </div>
                )}
              </div>

              {generationState.resultUrl && (
                <div className="mt-8 flex flex-col items-center gap-4">
                  <a 
                    href={generationState.resultUrl} 
                    download="luxe-jewel-ai.png"
                    className="px-12 py-5 bg-[#222] border border-[#333] hover:bg-[#333] text-white font-black uppercase tracking-[0.2em] rounded-full text-xs hover:scale-105 transition-all shadow-lg flex items-center gap-3"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                    Download Image
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="p-8 text-center">
        <p className="text-zinc-800 text-[10px] font-black uppercase tracking-[0.6em] opacity-40">
          POWERED BY GEMINI AUTO-SCALING
        </p>
      </footer>
    </div>
  );
};

export default App;